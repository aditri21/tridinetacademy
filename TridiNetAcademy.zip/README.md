#Coaching--Learning-Managment

>Coaching-Learning-System is a multi-purpose, high quality eLearning template LMS (Learning management system) for teachers, instructors, education center, schools, universities to create and manage your own online course website. This template flexibility and power can help you easily create beautiful online courses, share your knowledge.


#Pages<br>
1.Home<br>
2.About<br>
3.Teacher<br>
4.Course<br>
5.Galerry<br>
6.FAQ<br>
7.Question<br>

#Features<br>

✔HTML5 & CSS3 <br>
✔Pixel Perfect Design <br>
✔Responsive Design <br>
✔User Friendly Code<br> <br>
✔Clean Markup<br> 
✔Creative Design <br>
✔Cross Browser Support <br>
✔Powered With Bootstrap 3 <br>


#Source & Credits<br> 

1.BootStrap  <br>
2.Google font <br>
3.Jquery Library<br>
4.Font Awesome <br>
